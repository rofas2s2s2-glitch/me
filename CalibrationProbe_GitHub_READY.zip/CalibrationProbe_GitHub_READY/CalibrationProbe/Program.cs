using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;

namespace CalibrationProbe
{
    internal static class Program
    {
        static readonly string[] Targets = {
            "CalibrationFileHeaderStruct","CalibrationFileDataStruct",
            "CalibrationInfo","CalibrationFactory","Calibrator","RawImage",
            "ICalibrationInfo","ICalibrationFactory","ICalibrator"
        };

        static int Main()
        {
            string baseDir = AppDomain.CurrentDomain.BaseDirectory;
            string dll = Path.Combine(baseDir, "libs",
                "Sirona.Schick.SidexisPlugin.Velocity.Calibration.dll");
            string report = Path.Combine(baseDir, "CalibrationReport.txt");
            var sb = new StringBuilder();

            sb.AppendLine("MyDent - Sirona Calibration Assembly Probe");
            sb.AppendLine("==========================================");
            sb.AppendLine("OS: " + Environment.OSVersion);
            sb.AppendLine("Process: " + (Environment.Is64BitProcess ? "x64" : "x86"));
            sb.AppendLine("OS: " + (Environment.Is64BitOperatingSystem ? "x64" : "x86"));
            sb.AppendLine("CLR: " + Environment.Version);
            sb.AppendLine();

            if (!File.Exists(dll))
            {
                sb.AppendLine("ERROR: DLL not found: " + dll);
                File.WriteAllText(report, sb.ToString(), Encoding.UTF8);
                Console.WriteLine(sb);
                return 2;
            }

            AppDomain.CurrentDomain.AssemblyResolve += (s, e) => {
                try {
                    string n = new AssemblyName(e.Name).Name + ".dll";
                    string p = Path.Combine(baseDir, "libs", n);
                    return File.Exists(p) ? Assembly.LoadFrom(p) : null;
                } catch { return null; }
            };

            Assembly asm;
            try {
                asm = Assembly.LoadFrom(dll);
                sb.AppendLine("Assembly: " + asm.FullName);
                sb.AppendLine("Runtime: " + asm.ImageRuntimeVersion);
                sb.AppendLine();
            } catch (Exception ex) {
                sb.AppendLine("ERROR loading assembly:");
                AddException(sb, ex);
                File.WriteAllText(report, sb.ToString(), Encoding.UTF8);
                Console.WriteLine(sb);
                return 3;
            }

            Type[] types;
            try { types = asm.GetTypes().OrderBy(t => t.FullName).ToArray(); }
            catch (ReflectionTypeLoadException ex) {
                types = ex.Types.Where(t => t != null).OrderBy(t => t.FullName).ToArray();
                sb.AppendLine("TYPE LOAD WARNINGS:");
                foreach (var e in ex.LoaderExceptions) sb.AppendLine(e.Message);
                sb.AppendLine();
            }

            sb.AppendLine("ALL TYPES");
            sb.AppendLine("----------");
            foreach (var t in types) sb.AppendLine(t.FullName);
            sb.AppendLine();

            foreach (string name in Targets)
            {
                Type t = types.FirstOrDefault(x =>
                    string.Equals(x.Name, name, StringComparison.OrdinalIgnoreCase));
                if (t != null) DumpType(sb, t);
            }

            sb.AppendLine("ALL METHODS");
            sb.AppendLine("-----------");
            foreach (var t in types)
                foreach (var m in t.GetMethods(BindingFlags.Public|BindingFlags.NonPublic|
                                               BindingFlags.Instance|BindingFlags.Static|
                                               BindingFlags.DeclaredOnly).OrderBy(x => x.Name))
                    sb.AppendLine(t.FullName + "." + FormatMethod(m));

            File.WriteAllText(report, sb.ToString(), Encoding.UTF8);
            Console.WriteLine(sb);
            Console.WriteLine("REPORT: " + report);
            return 0;
        }

        static void DumpType(StringBuilder sb, Type t)
        {
            sb.AppendLine("TYPE");
            sb.AppendLine("====");
            sb.AppendLine(t.FullName);
            sb.AppendLine("BaseType: " + (t.BaseType == null ? "(null)" : t.BaseType.FullName));
            sb.AppendLine("IsValueType: " + t.IsValueType);
            if (t.IsValueType && !t.IsEnum)
            {
                try { sb.AppendLine("Marshal.SizeOf: " + Marshal.SizeOf(t)); }
                catch (Exception e) { sb.AppendLine("Marshal.SizeOf ERROR: " + e.Message); }
            }

            sb.AppendLine("FIELDS");
            foreach (var f in t.GetFields(BindingFlags.Public|BindingFlags.NonPublic|
                                          BindingFlags.Instance|BindingFlags.Static|
                                          BindingFlags.DeclaredOnly).OrderBy(x => x.MetadataToken))
            {
                string off = "n/a";
                if (!f.IsStatic && t.IsValueType)
                {
                    try { off = Marshal.OffsetOf(t, f.Name).ToInt32().ToString(); }
                    catch (Exception e) { off = "ERROR: " + e.Message; }
                }
                sb.AppendLine(f.Name + " | " + f.FieldType.FullName +
                              " | Static=" + f.IsStatic + " | Offset=" + off);
            }

            sb.AppendLine("PROPERTIES");
            foreach (var p in t.GetProperties(BindingFlags.Public|BindingFlags.NonPublic|
                                               BindingFlags.Instance|BindingFlags.Static|
                                               BindingFlags.DeclaredOnly).OrderBy(x => x.Name))
                sb.AppendLine(p.Name + " | " + p.PropertyType.FullName);

            sb.AppendLine("METHODS");
            foreach (var m in t.GetMethods(BindingFlags.Public|BindingFlags.NonPublic|
                                           BindingFlags.Instance|BindingFlags.Static|
                                           BindingFlags.DeclaredOnly).OrderBy(x => x.Name))
                sb.AppendLine(FormatMethod(m));
            sb.AppendLine();
        }

        static string FormatMethod(MethodInfo m)
        {
            string ps = string.Join(", ", m.GetParameters().Select(p =>
                (p.ParameterType.IsByRef ? "ref " : "") +
                p.ParameterType.FullName + " " + p.Name));
            return m.Name + "(" + ps + ") : " + m.ReturnType.FullName;
        }

        static void AddException(StringBuilder sb, Exception e)
        {
            sb.AppendLine(e.GetType().FullName + ": " + e.Message);
            if (e.InnerException != null) { sb.AppendLine("Inner:"); AddException(sb, e.InnerException); }
        }
    }
}
