# CalibrationProbe

مشروع مستقل لتحليل Sirona.Schick.SidexisPlugin.Velocity.Calibration.dll.

- .NET Framework 4.8
- x86
- Windows
- لا يعدل MyDent

ضع DLL داخل:
libs/Sirona.Schick.SidexisPlugin.Velocity.Calibration.dll

ضع أي Dependencies مطلوبة في نفس مجلد libs.

GitHub:
1. استخدم Repository خاص Private.
2. ارفع المشروع وDLL.
3. Actions -> Calibration Probe -> Run workflow.
4. حمّل Artifact باسم CalibrationProbe-Report.

لا تجعل المستودع عامًا إذا كانت DLL أو ملفات المعايرة مملوكة أو مرخصة.
